# ValtisFactory Changelog

## 0.1.25 — 2026-10-13
- Fixed GUI selecting too many items making Ok/Confirm unclickable.
- Added optional integration with StaffTurret's Turret Pylon. The Pylon can be registered and linked as an end-consumer node, using the existing consumer color.
- Supported Pylon fuel types and their stock values are read from the installed StaffTurret mod. Linked chests can automatically replenish its fuel stock while respecting existing source-reserve settings and inventory capacity.
- No StaffTurret dependency is required. The integration stays inactive when StaffTurret is not installed. Existing manual Pylon deposits and turret auto-refueling remain unchanged.

- Added per-Turret-Pylon refill target and restart threshold (0-5,000 charge points). Once refill begins at the threshold, it continues until the target is reached, including after world reload.
- Pylon refills now use each fuel item's actual charge value, allow the final item to exceed the chosen target, and never exceed the physical 5,000-point limit. Existing chest reserves and optional StaffTurret integration remain unchanged.

## 0.1.24 — 2026-10-12

- Fixed container node copy/paste not copying its incoming and outgoing logistics connections. Copying chest settings now also copies direct chest-to-chest routes, producer material supply/output storage routes, and crafting station input/output connections.
- Allowed route copying between different chest prefabs without deleting the destination chest's existing connections, name, identity, inventory, or unrelated item settings. Already-connected routes are not duplicated.
- Blocked the paste before saving if it would create a same-item chest transfer cycle or if a required linked endpoint is unavailable.

## 0.1.23 — 2026-10-12

- Added copy and paste of storage settings between container nodes even when their chest prefabs differ. Item supply permissions, minimum/priority reserves, and storage targets can be reused without replacing the destination chest's existing links, name, identity, or inventory.
- Fixed the Wisp Fountain output being hidden until the player had picked up a Wisp. Its fixed Wisp output is now selectable immediately.
- Updated the build installer and distribution package to place `ValtisFactory.dll` under `BepInEx\plugins\Haraneun-ValtisFactory`. The installer also removes legacy ValtisFactory DLL copies after the new installation succeeds.
- Updated the exact Valheim assembly build gate for Valheim 1.0.17 after checking the supplied Managed assemblies and decompiled game code. The build still rejects unverified game revisions.

## 0.1.22 — 2026-10-05

- Fixed automated producers restarting after entering or reloading a world even when their configured storage targets were already satisfied. Linked chest stock is now evaluated only after the saved inventories have finished restoring.
- Fixed chest-to-chest logistics and automated CraftingStation jobs acting on temporarily empty loading chests, which could move finished stock away and trigger unnecessary replacement production.
- Automation resumes automatically as soon as the required linked chests are ready, without requiring manual interaction.

## 0.1.21 — 2026-10-05

- Fixed automated stone-oven/cooking logistics briefly acting before linked containers had finished restoring after portal travel or world reload. Cooking automation now waits for the configured linked-container snapshots to become ready instead of treating a temporarily unloaded container as a real blocked route.
- Fixed blocked raw/cooked recovery so unresolved, still-loading, out-of-range, or ownership-pending linked containers pause the decision instead of authorizing an early ground fallback. Ground fallback is reserved for a fully resolved network that is genuinely unable to accept the item.
- Fixed remote-owner raw-return handling by requesting container ownership instead of treating a non-owned source chest as unavailable.
- Fixed an existing Burnt/Coal slot preventing later finished food from being handled. Burnt/Coal is now ejected through the native cooking-station removal path so later Done items can continue through normal storage/return handling.

## 0.1.20 — 2026-10-03

- Reduced brief stutters when windmills, spinning wheels, smelters, and other Smelter-family producers refill many material slots from a linked source chest at once.
- Optimized repeated source-chest save/change handling during the same automatic material refill while preserving existing material priority, shared-source distribution, MinimumReserve, rollback, and vanilla one-item insertion behavior.

## 0.1.19 — 2026-10-02

- Fixed an issue where bread or other finished stone-oven food could remain in the oven long enough to continue cooking and turn into charcoal.
- Finished automated food is now handled before the next cooking step: it is moved to storage when possible, otherwise the existing safe return/ejection path is used instead of allowing it to burn.

## 0.1.18 — 2026-10-02

- Added direct chest-to-chest logistics. Destination chests can keep a requested amount or be filled to physical capacity, and finite targets move only the amount still missing.
- Simplified destination stock control to a single **Storage target** and synchronized the same target between producer-to-chest and chest-to-chest automation.
- Improved SeedBed automation for shared and bidirectional farm layouts. Self-multiplying crops such as flax or barley can continue their own growth cycle without weakening the protected reserve used by other machines.
- Cooking stations and stone ovens now return a blocked raw ingredient instead of letting it continue toward charcoal when its finished product has already reached the storage target, then try the next available production-priority item.
- Improved world-load behavior for smelters, charcoal kilns, windmills, and other automated producers. They wait when their configured output destination is not available, and current chest materials/fuel are no longer consumed as if they had been present during unloaded elapsed time.
- Fixed Fermenters restarting a high-priority mead on world entry before the destination chest inventory had finished loading. A completed batch still goes into storage if it physically fits even when it slightly exceeds the target; after collection, that product stops and the next runnable priority item is evaluated.

## 0.1.17 — 2026-10-01

- Fixed a SeedBed compatibility regression introduced by the readiness-boundary revision. `IsReady()` and `SlowUpdate()` are now optional acceleration hooks instead of mandatory contract members; the core SeedBed 1.2.9 RPC/conversion contract remains sufficient for integration.
- SeedBed type resolution now prefers the exact loaded SeedBed plugin assembly and receives one event-driven final retry at `ZNetScene.Awake` before the endpoint catalog is finalized.
- When native readiness/wake hooks are unavailable, ValtisFactory falls back to the existing germination duration/start-time state and a single completion-boundary wake instead of disabling all SeedBed endpoints.
- SeedBed contract failure warnings now report the exact required member that could not be resolved.

- Fixed an issue where a Fermenter could briefly be treated as empty while automatic collection was still in progress, allowing a new mead base to enter too early and causing the finished mead to be dropped outside.
- Completed Fermenter batches now ignore the configured **Maximum stock** when being moved to their destination. Maximum stock and **Resume production** control whether the next fermentation may begin; a batch that has already finished is stored even if it temporarily pushes the chest above the target amount.
- **Manual collection required** is now shown for a completed Fermenter only when the destination chest genuinely lacks enough physical inventory space for the whole batch.

## 0.1.16 — 2026-09-30

- Improved Verbose output-capacity diagnostics. Blocked routes now distinguish `stock_limit`, `stock_hysteresis`, `inventory_full`, `batch_too_large`, `target_unloaded`, `out_of_range`, and `invalid_target`, with current stock, resume/max targets, physical addable amount, slot usage, stack size, and source/target IDs where applicable.
- Added Verbose-only player/container transfer tracing for VF-registered containers. Actual moved amounts are derived from inventory deltas and cover normal moves, partial-stack moves, Take All, Stack All, and multi-item transfers.
- Added optional VanillaAreaPickup 0.4.9 Quick Stack attribution. Quick Stack transfers can be labeled `cause=quick_stack` without making VAP a dependency. If VAP is absent or its inspected internal state changes, the integration fails silently and VF continues normally.
- Transfer hooks exist only while client-side diagnostics are enabled at Verbose level. Diagnostics OFF performs no new transfer snapshots, container scans, VAP reflection, diagnostic string construction, or background polling.
- Fixed destination-stock hysteresis semantics for completed producer output. The **Resume production** threshold now controls only whether a **new production cycle may start**. A batch that has already finished is moved to its destination whenever the entire batch fits below the configured **Maximum stock** and the container has physical room.
- Fermenter Ready batches therefore no longer remain completed indefinitely merely because destination stock is above the resume threshold. Example: with Resume=12 and Maximum=30, a completed batch of 6 at stock 23 is routed to make 29, then new production waits until stock falls to the resume threshold.
- The **manual collection required** warning is now reserved for a real completed-output capacity block: the finished batch cannot fit under the hard stock limit or physical inventory capacity. Hysteresis alone no longer triggers or sustains that warning.
- The same completed-output rule is used for CookingStation done-item routing, preventing an already-finished item from being treated as blocked solely by the low-water latch.