# ValtisFactory — Quick Usage Guide

ValtisFactory supports **English, Korean, and Japanese**.  

Easy to use, simplistic, automation.

---

## Build compatibility

The included Windows build script checks for the exact Valheim **1.0.17** `assembly_valheim.dll` before compiling. Its release output installs to `BepInEx\plugins\Haraneun-ValtisFactory\ValtisFactory.dll`. Other game versions require a new API audit.

## Before You Start

ValtisFactory is mainly intended for solo players who enjoy building and managing a base, but do not want to spend too much of their playtime on repetitive production and logistics.

Multiplayer is supported, but heavy automation may reduce some of the fun of dividing work and cooperating with other players.

ValtisFactory is closer to a **workflow tool** than a simple utility mod. You decide where materials come from, where they go, what gets produced first, and where the results are stored.

Because of this, the initial setup may feel a little complicated. No mod is perfect from the beginning, and small usability improvements are still being made. Feedback is always welcome.

ValtisFactory currently supports **English, Korean, and Japanese**. Additional language patches are not planned for now, but I may add more languages after the tool itself is fully refined.

---

## Mod Compatibility

Production buildings from other mods that use their own completely new production logic may not be recognized by ValtisFactory.

Compatibility for those buildings is planned to be added later through mod-specific compatibility patches.

Production buildings based on **vanilla production logic**, as well as craftable items added by mods, are automatically scanned and added when the game starts whenever they can be handled by the existing system.

---

## Basic Usage

- Look at a building or chest and press `]` to register it as a ValtisFactory node.
- Press `F8` to open the production graph.
- `F8` and `]` are only the default keys and can be changed at any time in the config.
- Connect material sources, production buildings, storage containers, fuel consumers, ammunition consumers, and other supported endpoints.
- Source containers can keep a **minimum reserve**.
- Destination containers use one **storage target** per item. The hidden compatibility resume value is maintained automatically at target - 1.

---

## Example 1 — Wood Arrow Stock

https://youtu.be/DQWYicdMEEI

---

## Example 2 — Charcoal, Smelting, and Multi-Stage Production

https://youtu.be/wDxXhuRDA5o

Example setup:

- One chest containing Wood and Core Wood
- Two Charcoal Kilns
- One Coal chest
- One chest containing Copper Ore and Tin Ore
- Two Smelters
- One Copper Ingot chest
- One Tin Ingot chest

From the mixed Wood/Core Wood chest, select only **Core Wood** and send it to the Charcoal Kilns. Wood can remain untouched in the same chest.

Produced Coal can be sent to a storage chest:

**Charcoal Kiln → Coal Chest**

Buildings with a separate fuel stock, such as Smelters, can also receive the product directly as fuel:

**Charcoal Kiln → Smelter Fuel**

Both routes can exist at the same time:

**Charcoal Kiln → Coal Chest**  
**Charcoal Kiln → Smelter Fuel**

When storage and a production consumer are both connected, storage is filled first. If the storage destination can no longer accept the item, it can then be sent to the production building.

The Copper Ore and Tin Ore chest can supply both Smelters.

Each Smelter can have a different production priority:

**Smelter A: Copper → Tin**  
**Smelter B: Tin → Copper**

When a Smelter-class building is loaded again after being unloaded, Valheim first catches up elapsed production time using only the ore/fuel already inside that machine. ValtisFactory resumes chest-backed material/fuel refill only after that vanilla catch-up finishes, so newly available chest stock is not retroactively consumed as if it had been present during the unloaded period.

Copper and Tin Ingots can be sent to separate storage chests, or used as materials for the next production stage.

**Copper / Tin → Forge → Bronze → Finished Product Chest**

The same workflow concept also applies to supported **Cooking Stations and Fermenters**, allowing production to continue through several stages until the finished product reaches storage.

---

## Example 3 — One Chest, Many Consumers

https://youtu.be/C00gK143NVU

A single chest may contain:

**Wood + Core Wood + Resin**

Different materials can be routed independently:

**Core Wood → Charcoal Kilns**  
**Resin → 5 Wood Torches**  
**Wood → Workbench or another production line**

Each material can also keep its own minimum reserve.

This is not limited to torches. Workflows can begin with raw materials and continue all the way to automatic ammunition production and supply:

**Raw Materials → Processing → Crafting → Ammunition Storage → Ballistas**

---

ValtisFactory is designed so that a small production line can gradually grow into a complete automated production and logistics network.


## Optional StaffTurret Turret Pylon integration (0.1.25)

When StaffTurret 0.1.78 (Valheim 1.0.17) is installed, its Turret Pylon can be registered with `]` and connected to supply chests as a final-consumer (fuel-only) node. Fuel types and their value are discovered through StaffTurret's runtime `Worth(string)` contract; no StaffTurret dependency is declared. Source-container reserves and Pylon stock limits are respected. Alt/Ctrl+Interact opens the supply editor; unmodified/Shift+Interact retains the Pylon's own manual fueling. No changes are required to StaffTurret.

This version's compatibility implementation has not yet been compiled on Windows/net48 or verified in-game or on a dedicated server.

### Optional Turret Pylon refilling (StaffTurret)

With StaffTurret installed, register its Turret Pylon as a consumer node and open its fuel-source settings. The Pylon-only fields **Fill target** and **Refill at or below** use charge points (0–5,000), not item counts. Once triggered, automatic refill continues up to the target; individual fuels provide different point amounts and the last one can slightly overshoot the target without crossing the physical 5,000-point capacity. Settings are per-Pylon. StaffTurret remains optional.
