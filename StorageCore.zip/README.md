# Storage Core

A standalone storage network for Valheim, inspired by Magic Storage (Terraria) and Refined Storage (Minecraft).
Only needs BepInEx.

Build a **Storage Core** and every chest you can access nearby becomes one big, searchable storage.
Replace your pile of chests with **Rune Vaults**: stone storage blocks for the core that you upgrade in place.

## Screenshots

**The three Storage Cores:** Classic, Obelisk (4 m) and Obelisk

![Storage Core Classic, Obelisk 4 m and Obelisk](https://i.imgur.com/e4jzTPG.png)

**Storage window:** every item of every connected chest in one place

![Storage window](https://i.imgur.com/l57PsUs.png)

**Crafting with the stations in range**

![Crafting tab](https://i.imgur.com/aHOoxyl.png)

**Upgrade the gear you carry**

![Upgrade tab](https://i.imgur.com/4Et1CzK.png)

**Obelisk colours:** each obelisk can have its own glow colour (the Classic core keeps its look)

![Obelisk colours](https://i.imgur.com/utqQ4MR.png)

**All controls** on one page (the ? button)

![Controls page](https://i.imgur.com/Q1LRE0L.png)

**Rune Vaults** next to a Storage Core: the runes glow in the core's colour, brighter the fuller a vault is

![Rune Vaults next to a Storage Core, fill shown by the glow](https://i.imgur.com/mM6VOJW.jpeg)

**The same vaults with a green core colour**

![Rune Vaults with a green core colour](https://i.imgur.com/X38RbiV.jpeg)

**Vault panel:** press E on a vault

![Vault panel](https://i.imgur.com/HuDqGxs.png)

**Vaults tab** in the core window: every vault in range with its tier, fill and next upgrade

![Vaults tab](https://i.imgur.com/3KTtXCv.png)

## Features

- **Storage Core** build piece (Hammer → Crafting tab, needs a workbench) in three looks: the rune-carved **Storage Obelisk**
  (about 2.6 m tall, 1.2 m footprint), the big **Storage Core (4 m)** obelisk (about 4 m tall, 1.8 m footprint), or the
  **Classic** look (the vanilla ward stone model, tinted). Each look is its own piece, so already built cores never change. Costs 10 Fine wood, 5 Bronze and 2 Surtling cores (configurable with `BuildCost`).
- **Auto-connect**: all chests within 20 m of the core are connected (radius is configurable). Hover the core to see its range.
- **Search & take**: one window lists every item in every connected chest. Type to search, sort by name, count or type.
  - Left-click: take a stack. Shift + left-click: take all. Right-click: take one.
  - Type a number into the **Amount** box and left-click takes (or stores) exactly that many.
- **Deposit with smart stacking**: items go to filtered or tagged chests for them first, then to chests that already
  hold the same item, then into free space (chests with similar items are preferred).
  - Click an item in your inventory to store that stack, or press **Deposit all**.
  - Shift + E on the core stores everything without opening the window.
- **Keep list**: right-click an item in your inventory panel to mark it **KEEP**. Kept items are never deposited.
  Hotbar, equipped items and ammo are kept by default (configurable). The list is saved per character.
- **Crafting**: the Crafting tab shows the recipes you know for the stations in range of the core, using materials from
  your inventory **and** the chests. Recipes you lack materials for are shown greyed out (config `ShowUncraftableRecipes`).
  Shift = craft 10, Ctrl = craft as many as possible.
- **Upgrade tab**: upgrade the gear you are carrying with the stations in range, using chest materials. Special
  upgrade stations where an upgrade can fail stay vanilla-only.
- Crafting and upgrading in the core run **Valheim's own crafting code**, so lucky bonus crafts, more output from better
  ingredients, skill experience and crafting stats work like at the station, and so do changes other mods make to
  Valheim's crafting.
- **Vanilla stations and building use the network too**: stand inside a core's radius and your workbench, forge, cauldron etc.
  and the hammer can use materials from the connected chests (both configurable).
- **Obelisk colour**: click one of the colour dots at the top of the window to change the glow, crystals and sparks of
  that obelisk. Saved on the obelisk, everyone sees it, every obelisk can have its own colour.
- **Themes**: the **Theme** button switches the window colours (Valheim, Dark stone, Frost, Ember, Mistlands), per player.
- **Controls help**: the **?** button at the top of the window shows every control, one per line.
- **Exclude a chest**: look at a connected chest and press **K** to disconnect/reconnect it.
- **Chest filters and tags**: look at a chest and press **L**:
  - first press: the chest only accepts the item types inside it (fill it first, e.g. with your ores; an empty chest
    starts with the tags),
  - press again to cycle through category tags: **Food, Armor, Weapons, Materials, Smelter, Tools, Trophies, Misc**, then off,
  - **Shift + L** removes the filter at once.

  Deposits go to the most fitting chest first: item filter, then Smelter tag, then the other tags. When those are full,
  they go to unfiltered chests that already hold the item, then (config `DepositIntoAnyChest`, on by default) to any
  unfiltered chest with room. A filtered chest never takes items outside its filter. **Tidy chests** moves items into the
  best fitting filtered chest in the same order. **Smelter** means what the smelter and blast furnace take (ores, scrap and
  the like) plus coal, and the same for furnaces from other mods that burn coal. Eitr refinery items (sap, soft tissue)
  are not Smelter items.
- **Categories, pins and tooltips**: filter the storage grid **and the crafting lists** by category (incl. Smelter), pin favourites to the top (middle click / Alt + click),
  hover for the full item tooltip, Ctrl + click to make the chests holding an item glow (20 s, only on your screen).
- **Tidy chests**: one button moves items into the filtered chests made for them and merges half-full stacks across
  all chests.
- **Refill**: tops up the food, meads, other consumables and ammo you already carry to a full stack from the chests
  (never gear).
- **Repair all**: repairs all worn gear in your inventory with the stations in range of the core, with the same rules
  as vanilla, in one click (config `RepairNeedsStation`).
- **Amount buttons**: -5 / -1 / +1 / +5 next to the Amount box. Hold Shift and they become -50 / -10 / +10 / +50.
  Right-click the box to clear it.
- **Window size**: use the - / + buttons in the window header (saved per player).

## Rune Vaults

Stone storage blocks made for the Storage Core (Hammer → Crafting tab, next to the core, needs a workbench).

- **1 m block with 16 slots** that snaps side by side and on top of other vaults, so a few vaults replace a wall of
  chests. Costs 10 Wood and 10 Stone (configurable with `VaultBuildCost`).
- **Used through the core**: a vault is a normal chest for the Storage Core (take, store, crafting, Tidy, Refill,
  filters with **L**, disconnect with **K**), but it has no chest window of its own.
- **E on a vault** opens its panel: tier, used slots, filter, the next upgrade, an **Upgrade** button and
  **Drop all items** (click twice), which empties the vault into floating crates next to it, e.g. while rebuilding.
- **Upgrade in place**: look at a vault and press **U** (or use the Upgrade button). Items stay where they are, the
  vault just gets bigger. Materials come from your inventory and the chests of a core nearby, and the station must be
  near the vault:

  | Tier | Slots | Upgrade cost | Station |
  |---|---|---|---|
  | 1 | 16 | build cost | Workbench |
  | 2 | 24 | 4 Bronze, 10 Fine wood | Forge |
  | 3 | 32 | 6 Iron, 10 Stone | Forge |
  | 4 | 40 | 6 Silver, 6 Obsidian | Forge |
  | 5 | 48 | 8 Black metal, 6 Linen thread | Forge |
  | 6 | 56 | 10 Black marble, 4 Eitr | Black forge |
  | 7 | 64 | 6 Flametal, 10 Grausten | Black forge |

  The table is configurable (`VaultTiers`); changing it never makes vaults that are already upgraded smaller. In worlds
  with "No build cost", upgrades are free. Each tier shows what it is made of: timber, bronze, iron, silver or black
  metal fittings, eitr glow, flametal.
- **Nothing is lost**: a vault with items in it cannot be removed with the hammer (empty it first). Removing a vault
  gives back its build cost **and everything paid for its upgrades**. A destroyed vault leaves its items in crates.
- **Vaults tab** in the core window: every vault in range with tier, fill, filter and the next upgrade's materials, an
  **Upgrade** button per vault, and a click on a vault makes it glow (20 s).
- **Vaults first**: storing prefers vaults – after the chests filtered for an item, it goes to vaults that already
  hold it, then to vaults with room, and only then to normal chests (config `VaultsFirst`).
- **Move into vaults** (Vaults tab): moves the contents of your normal chests into vaults with room in one click,
  following your filters. The chests that are empty afterwards glow for 20 s, so you can find and remove them.
- **Glowing runes**: a vault glows in the colour of the nearest Storage Core (its colour dots) and the brighter the
  fuller it is, so a wall of vaults shows at a glance where there is room.
- Works with Valheim Plus machines that pull from and deposit into nearby chests (smelters, kilns, fermenters ...).

## Fast, but fair

- Taking and storing is instant: no animations, no waiting.
- **Private chests** only connect for their owner, and chests inside a **ward** you are not permitted in are never connected.
- Only chests built by players are connected (no dungeon loot chests, no graves). Carts and ships are off by default.
- **Safety check**: every take, store, tidy, refill, craft and upgrade compares item counts before and after and corrects
  any difference (logged). This includes crafts at normal stations that use chest materials, and "one of these"
  recipes like raw fish (checked by fish type and level). Items given back go into your inventory, or into a chest
  with room when it is full. Set `LogEveryTransfer = true` to log every transfer and action while testing
  (handy for bug reports).
- **Bug reports and ideas**: on GitHub, https://github.com/theSquareFacedGod/ValheimStorageCore/issues. Typing
  `storagecore_dump` in the console (or `/storagecore_dump` in chat) writes the state of the cores and chests around you
  into `LogOutput.log` - attach that file to the report.
- **Light on the network**: each chest is saved once per action, not once per stack change.
- **Multiplayer safe**: a chest only changes when your client owns it, exactly like vanilla does when you open a chest.
  Opening the core window locks nothing: everyone sees the chests live, several players can use the same core, and
  chests can still be opened normally. A chest is only claimed for the moment items move (plus one second). Chests that
  someone has open in the normal chest window are skipped until they are free.
- **Building together**: several players can build and craft from the same core's chests at the same time. If the
  materials are in a chest another player just used, that one click is skipped ("place again" / "craft again") while
  the chest comes over - the next click works.

## Multiplayer

Every player needs the mod, all on the same version (from 1.2.0 on, the mod warns when versions differ). Players on an
older version cannot see Rune Vaults. Installing it on a dedicated server is recommended: then these server settings
are used by everyone: core radius, build costs of the core and the vault, the vault tier table, only player-built
chests, whether stations and building use chest materials, and whether Repair all needs a station.

## Configuration

`BepInEx/config/StorageCore.cfg` (created after the first start). Keep lists and pins are stored per character in
`BepInEx/config/StorageCore/`. The build menu entries can be hidden one by one (`BuildMenuObelisk`, `BuildMenuObelisk4m`,
`BuildMenuClassic`, `BuildMenuVault`). Vault settings: `VaultBuildCost`, `VaultTiers` (one entry per tier from tier 2 on,
`Slots=Item:Amount,Item:Amount@StationPrefab`, separated by `;`), `VaultUpgradeKey` (default U) and `VaultsFirst`.

## Known limitations

- English only.
- The recipe list in the core's Crafting tab is built by the mod from Valheim's rules (known recipe, station and
  station level in range, materials). Extra conditions that other mods add to recipes may not show up in that list;
  use the normal station for those.
- **Valheim Plus "Craft From Chest"**: while it is on, Storage Core leaves normal crafting stations and the build menu
  to Valheim Plus, so no chest is counted twice (a note is written to the log). The Storage Core window works as usual.
- Other mods that also let you craft or build from chests (craft-from-containers mods) may conflict. Use one of them.
- Tested in single player and in a player-hosted game with two players. Not tested on a dedicated server yet; install
  the mod on the server as well. Rune Vaults: tested in single player so far.
- **Rune Vaults need the mod**: if you remove Storage Core, vaults and their contents are gone from the game until you
  install it again. Empty them first (Drop all items).
- Rune Vaults have no Deep North tier yet.

## Installing manually / with r2modman

- **r2modman / Thunderstore Mod Manager**: Settings → *Import local mod* → pick `StorageCore-x.y.z.zip`.
- **Manual**: copy `plugins/StorageCore.dll` into `BepInEx/plugins/StorageCore/`.

## License

Free to use on any computer or server and in videos. No reuploads. If a Valheim update breaks the mod and no fixed
version is out yet, anyone may publish a fixed version right away under a different name, with credit and a link to
this page, and step aside once the original is updated again. See `LICENSE.md` for the full text.
