# Changelog

## 1.2.0
**Rune Vaults** – stone storage blocks for the Storage Core
- New piece: **Rune Vault**, a 1 m stone storage block for the Storage Core (16 slots). It is filled and emptied
  through the core; E on a vault shows its info and a "Drop all items" button. It can only be removed when empty, and
  a destroyed vault leaves its items in crates. Build cost `VaultBuildCost` (synced from the server).
- **Vault upgrades**: look at a vault and press **U** (or use the Upgrade button in its panel) to raise its tier
  in place: 16 → 24 → 32 → 40 → 48 → 56 → 64 slots, with materials from the biomes (bronze, iron, silver, black metal,
  black marble and eitr, flametal) and a forge or black forge near the vault. Items stay where they are. Removing a
  vault gives back the build cost and everything paid for upgrades. Tier table `VaultTiers` (synced from the server).
  In worlds with "No build cost", upgrades are free. Each tier shows what it is made of: timber, bronze, iron, silver or black metal fittings, eitr glow, flametal.
  Vaults snap side by side and on top of each other.
- Vault runes glow in the colour of the nearest core and brighter the fuller the vault is.
- **Vaults tab** in the core window: all vaults in range with tier, fill, filter and the next upgrade's materials,
  Upgrade button per vault, click = the vault glows.
- **Vaults first** when storing (config `VaultsFirst`, on by default), and a **Move into vaults** button that empties
  your normal chests into vaults (following your filters) and makes the emptied chests glow.

**Other changes and fixes**
- New: a warning on screen and in the log when another player or the server has a different Storage Core version.
  Everyone needs the same version.
- Fixed (multiplayer): two players building or crafting at stations near the same core took the chests away from each
  other every 3 seconds, so one of them often could not build ("missing requirements"). Now the build menu and stations
  count every connected chest, and a chest is only taken over when you actually place or craft and need its materials.
  If another player just used it, that one click is skipped ("place again" / "craft again") while it comes over.
- Fixed: with `AlwaysKeepEquipped` off, **Deposit all** stored equipped items while you kept wearing them. They are now
  taken off first (and put back on if they do not fit).
- Fixed: Ctrl + Craft ("as many as possible") for "one of these" recipes like raw fish now counts each ingredient and
  quality level separately (before it could be too many or too few).
- Fixed: stackable items with different styles (only from other mods) are now always stored in separate stacks, also
  by **Tidy chests**; before, the safety check could give back items that were not missing.
- Fixed: crafting a recipe (from other mods) that gives back one of its own ingredients in the core window no longer
  takes the crafted item away again.
- On a server with its own core radius, the build menu text and the range circle of the core now show the server's
  radius (and your own again after leaving that server).
- Performance: the Crafting and Upgrade tabs no longer stutter when the connected chests change often (e.g. Valheim
  Plus filling smelters from them); Tidy chests, Move into vaults and Deposit all are much faster with many chests; less
  work while building near a core; vaults and obelisks are hidden at a distance like Valheim's own pieces, and their
  small glowing parts cast no shadows.
- Dedicated servers: the pieces are built without models and textures (a server has no graphics card), which makes
  the server start faster and avoids errors there; one log line when the server loads a world (pieces registered,
  settings sent to players).
- Better logs for bug reports, without slowing down normal play: a short settings summary when you spawn, and errors
  caught inside the mod (at most once a minute). With `LogEveryTransfer` on also the results of window actions, where
  building and crafting materials came from, chest claims in multiplayer (from both sides), slow actions and which other
  mods hook the same game code. New command `storagecore_dump` writes the state of the cores and chests around you
  into the log.
- The description of the `FilterChestKey` setting now explains the category tags.

## 1.1.1
- Fixed: recipes that take "one of these" ingredients, like **raw fish**, did not use up the ingredient and gave too
  little (a Northern salmon gave 1 raw fish instead of 3). This happened whenever the mod was installed, also with the
  fish in your own inventory. They now work exactly like vanilla: one fish of the level Valheim picks is used up and you
  get the full amount.
- The safety check now also covers crafts at normal stations that use chest materials, and "one of these" recipes
  (checked by fish type and level).
- Items the safety check gives back go into a chest with room when your inventory is full, instead of being dropped
  (a fish dropped into water would swim away).
- Valheim Plus "Craft From Chest": while it is on, Storage Core leaves normal stations and the build menu to Valheim
  Plus. Before, both mods counted the same chests, so everything showed twice and you could craft or build with half
  the materials.
- The **Smelter** tag now means smelter and blast furnace only (ores, scrap, coal). Sap and soft tissue from the eitr
  refinery no longer go into Smelter chests.
- The "Crafted" message in the core shows the real amount, lucky bonus crafts included.
- Crafting from chests now follows Valheim's world level rule (only matters on worlds with a raised world level).

## 1.1.0
- New piece: **Storage Core (4 m)**, a bigger obelisk. Existing Storage Cores are not changed.
- **Obelisk colour in game**: colour dots at the top of the window change that obelisk's glow, crystals and sparks,
  for everyone.
- **Themes** for the window: Valheim, Dark stone, Frost, Ember, Mistlands (Theme button, saved per player).
- **Category tags for chests**: press L again after the item filter to cycle Food, Armor, Weapons, Materials,
  Smelter, Tools, Trophies, Misc. Shift + L removes the filter. New **Smelter** category for ores, scrap and fuel.
- The category buttons also filter the Crafting and Upgrade tabs.
- **Crafting and upgrading in the core now use Valheim's own crafting code**: lucky bonus crafts (+1), more output
  from better "one of these" ingredients (lowest quality used first), skill experience, crafting stats, cheat marks
  and changes by other crafting mods all work exactly like at the station.
- Fixed: recipes that take "one of these" ingredients could fail at normal stations when the ingredient was only in
  the chests.
- Faster mouse wheel scrolling (like Valheim's own lists, config `ScrollSpeed`).
- Even spacing between the inventory slots.
- Fixed: the cursor could flicker while the window was open.
- Performance: the obelisk is drawn with far fewer parts; chest checks are cached.
- New mod icon and build-menu icon from the real in-game obelisk.

## 1.0.1
- New **?** button at the top of the window: shows all controls on one page, one control per line.
- The inventory panel fits any inventory size (Valheim's own or bigger ones from other mods); the help text no
  longer runs over the window.

## 1.0.0
- First release.
