Storage Core – License

Copyright (c) 2026 the author of Storage Core ("the Author"). All rights reserved, except as stated below.

1. Using the mod
   You may download, install and use Storage Core for free, on your own computer and on any server,
   including public and community servers, and show it in videos and streams.

2. Modpacks
   You may list Storage Core as a dependency in a modpack. You may not include the files themselves;
   the modpack must download them from the official Thunderstore page.

3. No re-uploads
   You may not upload, publish or distribute Storage Core or a modified version of it anywhere, under
   any name, except as allowed in section 4.

4. If the mod is broken
   If a Valheim update has broken Storage Core and no fixed version is available yet, anyone may
   publish a fixed version right away, without waiting for the Author, as long as they:
     - give it a different name (for example "Storage Core Continued"),
     - credit the Author and link to the original mod page,
     - keep this license with it, unchanged, and
     - mark their version as deprecated or remove it once the Author publishes a working update again.
   For this purpose you may decompile or modify the source code.

5. No warranty
   Storage Core is provided "as is", without any warranty. The Author is not liable for any damage,
   including lost items or save data.
